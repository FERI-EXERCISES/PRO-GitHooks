# Preizkusanje Programske Opreme
